clear all
%close all

[filename,pathname]=uigetfile({'*.*'} ,'MultiSelect', 'on');
if isnumeric(filename)
    return
elseif iscell(filename)
    nf = length(filename);
else
    nf = 1;
end



for i=1:nf
    image = dicomread([pathname filename{i}]);
%    image = imread([pathname filename{i}]);
%    image(:,:) = XX;
%    size(image)
    im1(:,:,i)=image;
end  




% First section
im1=im1(:,:,1:480);

% volumeViewer(im1(:,:,1:end))
% volshow(im1,'BackgroundColor','white')
% 



  figure(43)
  orthosliceViewer(im1,'DisplayRange',[1400 2700])

  %   colormap(jet)
%    colorbar




im_temp=im1;
nxc1 = (203+333)/2; % x center for the first image
nyc1 = (203+330)/2; % y center
nxc480 = (207+338)/2; % x center for the last image
nyc480 = (200+328)/2;
num_images = 480;
for i =1:1:num_images
     nxc = (nxc480 - nxc1)/(num_images - 1) * (i - 1) + nxc1;
     nyc = (nyc480 - nyc1)/(num_images - 1) * (i - 1) + nyc1;
    dn = 61;
    im2(:,:,i)=im_temp(nyc-dn:nyc+dn,nxc-dn:nxc+dn,i);
end

%clean im1

figure(1)
subplot(1,2,1)
imagesc(im2(:,:,1))
axis square

subplot(1,2,2)
imagesc(im2(:,:,480))
axis square




[ny nx nz]=size(im2);
im2r = imresize3(im2, [dn*2+1   dn*2+1   nz*6.25/1.95] );
%im3 = imgaussfilt3(im2resize);

%im3 = smooth3(im2r);
im3 = (im2r);

im100=im3;
save('im100.mat','im100')

stop





















 
 
