close all
clear all

dn = 61;
  [nx ny nz]=size(im0);
 
    for k=1:ny
       for m=1:nx
          if ((k-(dn+1))^2+(m-(dn+1))^2>dn^2)
              im0(m,k,1:nz)=NaN;
              im1(m,k,1:nz)=NaN;
              im2(m,k,1:nz)=NaN;
              im3(m,k,1:nz)=NaN;
              im4(m,k,1:nz)=NaN;
              im5(m,k,1:nz)=NaN;
              im6(m,k,1:nz)=NaN;
              im7(m,k,1:nz)=NaN;
              im8(m,k,1:nz)=NaN;
              im9(m,k,1:nz)=NaN;
              im10(m,k,1:nz)=NaN;
              im15(m,k,1:nz)=NaN;
              im20(m,k,1:nz)=NaN;
              im25(m,k,1:nz)=NaN;
              im30(m,k,1:nz)=NaN;
              im100(m,k,1:nz)=NaN;
          end
       end
    end


dim1=im100-im0;
dim1_min = double(min(dim1(:)));
dim1_max = double(max(dim1(:)));
dim1(63:123,63:123,1:nz)= dim1_min - 1;
    for k=1:ny
       for m=1:nx
          if ((k-(dn+1))^2+(m-(dn+1))^2>dn^2)
              dim1(m,k,1:nz)= dim1_min - 1;
          end
       end
    end
vtkwrite('im100.vtk', 'structured_points', 'dim1', dim1); %transfer dim1 to vtk format in ParaView
