close all
clear all

dn = 61;
  [nx ny nz]=size(im0);
    for k=1:ny
       for m=1:nx
          if ((k-(dn+1))^2+(m-(dn+1))^2>dn^2)
              im0(m,k,1:nz)=NaN;
              im1(m,k,1:nz)=NaN;
              im2(m,k,1:nz)=NaN;
              im3(m,k,1:nz)=NaN;
              im4(m,k,1:nz)=NaN;
              im5(m,k,1:nz)=NaN;
              im6(m,k,1:nz)=NaN;
              im7(m,k,1:nz)=NaN;
              im8(m,k,1:nz)=NaN;
              im9(m,k,1:nz)=NaN;
              im10(m,k,1:nz)=NaN;
              im15(m,k,1:nz)=NaN;
              im20(m,k,1:nz)=NaN;
              im25(m,k,1:nz)=NaN;
              im30(m,k,1:nz)=NaN;
              im100(m,k,1:nz)=NaN;
          end
       end
    end

%im0 = im0*0.43+886.5;

figure(1)
dim=im100-im0;
m=nanmean(dim(:,:,:),[1 2]);
size(m)
Mdim=squeeze(m);
Mdim_ave = movmean(Mdim,fix(length(Mdim)/15));
hold on
plot(0.195*[1:length(Mdim_ave)],Mdim_ave)

x=0.195*[1:length(Mdim)]';
size(x)
size(Mdim)


T=table(x,Mdim);
writetable(T,'100.xlsx')
